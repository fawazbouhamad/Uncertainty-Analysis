% Uncertainty Analysis

%% Definitions
% General definitions and constants for the analysis
confidence_factor = 2; % For a 95% confidence interval, approximately 2 standard deviations
t_factor = 1.960; % For 95% confidence with infinite degrees of freedom
axes_labels = ["X-axis", "Y-axis", "Z-axis"]; % Labels for the axes used in the data

%% Load Datasets
% Load the .csv files of the ensambled bridge data
% Make sure to skip the headers row and the first column (time)

% Load Walking Slowly dataset
WalkingSlowly = readmatrix('walkingslowly_cal_ensamble_mean.csv', 'NumHeaderLines', 1);
WalkingSlowly = WalkingSlowly(:, 2:end); 

% Load Walking Fast dataset
WalkingFast = readmatrix('walkingfast_cal_ensamble_mean.csv', 'NumHeaderLines', 1);
WalkingFast = WalkingFast(:, 2:end);

% Load Jogging dataset
Jogging = readmatrix('jogging_cal_ensamble_mean.csv', 'NumHeaderLines', 1);
Jogging = Jogging(:, 2:end);

% Load Natural Frequency dataset
NaturalFrequency = readmatrix('naturalfrequency_cal_ensamble_mean.csv', 'NumHeaderLines', 1);
NaturalFrequency = NaturalFrequency(:, 2:end);

% Store datasets and their names in arrays for easier processing
datasets = {WalkingSlowly, WalkingFast, Jogging, NaturalFrequency};
dataset_names = {"Walking Slowly", "Walking Fast", "Jogging", "Natural Frequency"};

%% Define Uncertainty Analysis Function
% Function to calculate uncertainty metrics and plot results
function results_table = analyze_and_plot(data, axis_label, confidence_factor, t_factor, dataset_name, bin_count, U_bias, U_resolution_XY, U_resolution_Z, k)
    % Calculate the number of samples in the dataset
    num_samples = length(data);

    % Compute basic statistics
    mean_val = mean(data); % Average value of the data
    std_dev = std(data); % Standard deviation (population std dev)
    U_rand = std_dev / sqrt(num_samples); % Random uncertainty based on sample size
    conf_low = mean_val - confidence_factor * std_dev; % Lower bound of the confidence interval
    conf_high = mean_val + confidence_factor * std_dev; % Upper bound of the confidence interval
    precision_index = t_factor * std_dev; % Precision index as a measure of spread

    % Select resolution error based on the axis being analyzed
    if strcmp(axis_label, "Z-axis")
        U_resolution = U_resolution_Z; % Use Z-axis resolution error
    else
        U_resolution = U_resolution_XY; % Use X/Y axis resolution error
    end

    % Combine uncertainties to compute the combined and expanded uncertainties
    U_combined = sqrt(U_rand^2 + U_bias^2 + U_resolution^2); % Combined uncertainty
    U_expanded = U_combined * k; % Expanded uncertainty with coverage factor

    % Create a results table summarizing the analysis
    results_table = table(mean_val, std_dev, U_rand, U_combined, U_expanded, conf_low, conf_high, precision_index, ...
        'VariableNames', {'Mean', 'StandardDeviation', 'RandomUncertainty', 'CombinedUncertainty', 'ExpandedUncertainty', 'ConfidenceLow', 'ConfidenceHigh', 'PrecisionIndex'});

    %% Plot Gaussian distribution and histogram (only for Z-axis)
    if strcmp(axis_label, "Z-axis")
        figure; % Create a new figure for the plot
        yyaxis left; % Use left y-axis for Gaussian fit
        hold on; % Hold on to allow multiple plots
        ax_left = gca; % Get the current axes
        ax_left.YColor = 'k'; % Set left y-axis color to black

        % Generate Gaussian fit and plot it
        x_vals = linspace(min(data), max(data), 100);
        gaussian_fit = (1 / (std_dev * sqrt(2 * pi))) * exp(-0.5 * ((x_vals - mean_val) / std_dev).^2);
        plot(x_vals, gaussian_fit, 'r-', 'LineWidth', 2); % Red line for Gaussian fit
        ylabel('Gaussian Probability Density');

        % Highlight the 95% confidence interval
        x_conf = linspace(conf_low, conf_high, 100);
        y_conf = (1 / (std_dev * sqrt(2 * pi))) * exp(-0.5 * ((x_conf - mean_val) / std_dev).^2);
        fill([x_conf fliplr(x_conf)], [y_conf zeros(size(y_conf))], 'red', 'FaceAlpha', 0.5);

        % Add a vertical line for the mean
        yl = ylim;
        plot([mean_val mean_val], yl, 'k--', 'LineWidth', 2, 'DisplayName', 'Mean');

        yyaxis right; % Use right y-axis for the histogram
        ax_right = gca; % Get the current axes
        ax_right.YColor = 'k'; % Set right y-axis color to black
        histogram(data, bin_count, 'Normalization', 'count', 'FaceColor', 'cyan', 'DisplayName', 'Frequency');
        ylabel('Frequency');
        title(sprintf('%s Gaussian Distribution (Z-axis)', dataset_name));
        xlabel('Acceleration (g)');

        % Add legend and grid
        legend({'Gaussian Fit', '95% CI', 'Frequency', 'Mean'}, 'Location', 'Best');
        grid on; % Add grid lines
        hold off; % Release the hold on the figure
    end
end
%% Perform Uncertainty Analysis
% Initialize an overall results table to combine all results
overall_results = table();

% Loop through each dataset and perform uncertainty analysis
for i = 1:length(datasets)
    fprintf('Dataset: %s\n', dataset_names{i}); % Print dataset name
    dataset_results = table(); % Initialize a table for each dataset
    for axis_idx = 1:size(datasets{i}, 2)
        % Perform analysis and get results for the current axis
        results = analyze_and_plot(datasets{i}(:, axis_idx), axes_labels(axis_idx), ...
            confidence_factor, t_factor, dataset_names{i}, bin_counts(i), U_bias, U_resolution_XY, U_resolution_Z, k);

        % Add axis information to the results
        axis_results = addvars(results, repmat(axes_labels(axis_idx), height(results), 1), ...
            'Before', 'Mean', 'NewVariableNames', 'Axis');
        dataset_results = [dataset_results; axis_results]; % Append results
    end

    % Add dataset name to results
    dataset_results = addvars(dataset_results, repmat(dataset_names(i), height(dataset_results), 1), ...
        'Before', 'Axis', 'NewVariableNames', 'Dataset');
    overall_results = [overall_results; dataset_results]; % Append to overall results
end

%% Define Uncertainty Sources
% Constants for uncertainty calculations
temp_variation = 5; % Temperature variation in °C
bias_drift_per_degree = 1e-3; % Drift in g per °C
U_bias = bias_drift_per_degree * temp_variation; % Bias uncertainty

% Noise densities for each axis
noise_density_XY = 150e-6; % X and Y axes
noise_density_Z = 300e-6; % Z axis
bandwidth = 500; % Bandwidth in Hz

% Calculate resolution uncertainty for each axis
U_resolution_XY = noise_density_XY * sqrt(bandwidth);
U_resolution_Z = noise_density_Z * sqrt(bandwidth);

% Combine uncertainties and calculate expanded uncertainties
U_combined_XY = sqrt(U_rand^2 + U_bias^2 + U_resolution_XY^2);
U_combined_Z = sqrt(U_rand^2 + U_bias^2 + U_resolution_Z^2);

confidence_level = 0.95; % Confidence level
k = norminv((1 + confidence_level) / 2); % Coverage factor
U_expanded_XY = U_combined_XY * k; % Expanded uncertainty for XY
U_expanded_Z = U_combined_Z * k; % Expanded uncertainty for Z

% Print summary of uncertainty analysis
fprintf('Effective Degrees of Freedom: Infinite\n');
fprintf('Coverage Factor (k): %.2f\n', k);
fprintf('Confidence Level: %.2f%%\n', confidence_level * 100);

%% Display Results
% Display the overall uncertainty analysis results
disp('Overall Uncertainty Analysis Results:');
disp(overall_results);
